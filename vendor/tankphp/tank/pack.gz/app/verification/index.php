<?php
return [
        //*添加验证
        "add" => [
                '字段|中文名字|require' => "None",
        ],
        //*编辑验证
        "edit" => [
                '字段|中文名字|require' => "None",
        ],
        //*删除验证
        "delete" => [
                '字段|中文名字|require' => "None",
        ],
];