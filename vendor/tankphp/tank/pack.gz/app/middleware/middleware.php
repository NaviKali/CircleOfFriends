<?php
namespace app\middleware;

use function tank\BathVerParams;

/**
 * 中间件
 */
class middleware
{
        /**
         * 中间件定义
         * @static
         * @param array $params 接受参数
         * @param array $request 请求头
         * @param array $response 响应头
         * @return mixed
         */
        public static function Handle(array $params,array $request,array $response)
        {
        }
}
