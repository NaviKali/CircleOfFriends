<?php

#|----------------------------------|
#|       WECLOME TANK               |
#|     I LIKE PHP FROM THIS         |
#|      @email 2149573631@qq.com    |
#|----------------------------------|


namespace config;


return [
    //*是否禁止Edge浏览器使用
    "isStopEdge" => true,
];