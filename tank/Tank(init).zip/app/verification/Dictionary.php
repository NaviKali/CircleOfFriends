<?php
return [
        /**
         * 添加字典
         */
        'addDictionary' => [
                "dictionaryName|字典名字|require" => "None",
                "dictionaryType|字典类型|require" => "None",
                "dictionaryKey|字典Key|require" => "None",
                "dictionaryValue|字典Value|require" => "None",
                "dictionaryFatherGuid|字典父级Guid|require"=>"None",
        ]
];